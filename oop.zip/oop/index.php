<?php 

	include 'classes/database.php';
	include 'classes/dataclass.php';

	$dc = new dataclass();

	if(isset($_POST['submit'])){
		$result =  $dc->insertintodb($_POST);
		$result = $dc->showall();

		while($row = $result->fetch_assoc()){
			echo $row['fname']." ".$row['lname']."<br>";
		}

	}


 ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<title>Document</title>
 </head>
 <body>
 	<form method="post" action="">
 		<label>First Name</label><br>
 		<input type="text" name="fname" placeholder="Enter your name;"><br>
 		<label>Last Name</label><br>
 		<input type="text" name="lname"><br>
 		<label>Phone Number</label><br>
 		<input type="text" name="number"><br>
 		<input type="submit" name="submit">
 	</form>
 	
 </body>
 </html>