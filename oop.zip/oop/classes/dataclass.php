<?php 
	class dataclass{
		public $db;

		public function __construct(){
			$this->db = new DATABASE();
		}

		public function  insertintodb($post){
			$fname = $post['fname'];
			$lname = $post['lname'];
			$phone = $post['number'];

			$query = "INSERT into test_tbl values(null,'$fname','$lname','$phone')";

			$data = $this->db->run($query);
			return $data;
		}

		public function showall(){
			$query = "SELECT * from test_tbl";
			$data = $this->db->run($query);
			return $data;
		}
	}
 ?>