<?php 
$con = mysqli_connect("localhost","root","","ecommerce"); 

$keyword = $_POST['keyword'];
$search_data = mysqli_query($con,"SELECT * FROM `products` WHERE product_title LIKE '%".$keyword."%'");
/*echo "SELECT * FROM `products` WHERE product_title LIKE '%'".$keyword."'%'";*/
?>

<thead>
	<tr>
		<th>Title</th>
		<th>Price</th>
	</tr>
</thead>
<tbody>
	<?php
	while($row = mysqli_fetch_array($search_data)){ 
		?>
		<tr>
			<td><?php echo $row['product_title']; ?></td>
			<td><?php echo $row['product_price'] ?></td>
		</tr>
	<?php } ?>
</tbody>
<tfoot>
	<tr>
		<th>Title</th>
		<th>Price</th>
	</tr>
</tfoot>