<?php
$con = mysqli_connect("localhost","root","","ecommerce"); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Ajax Example</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">

	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
</head>
<body>


	<div style="margin: 50px;width: 100%;height: 500px;">
		<input type="text" id="name" name="" placeholder="Name" class="form-control">
<input type="number" id="number" name="" placeholder="number" class="form-control">
<input type="email" id="email" name="" placeholder="email" class="form-control">
<button onclick="submit_data()">Submit</button>
	</div>

	<div style="margin:0 auto;float: right;margin-right: 100px;"><input type="text" id="search" width="100%" placeholder="Search Here" onchange="get_data()"></div>


	<table id="example" class="table" style="width:100%;padding: 20px;">
		<thead>
			<tr>
				<th>Title</th>
				<th>Price</th>
			</tr>
		</thead>
		<tbody>
			<?php
			$data = mysqli_query($con,"SELECT * from products");
			while($row = mysqli_fetch_array($data)){ 
				?>
				<tr>
					<td><?php echo $row['product_title']; ?></td>
					<td><?php echo $row['product_price'] ?></td>
				</tr>
			<?php } ?>
		</tbody>
		<tfoot>
			<tr>
				<th>Title</th>
				<th>Price</th>
			</tr>
		</tfoot>
	</table>
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
	<script type="text/javascript">
	/*$(document).ready( function () {
		$('#example').DataTable();
		
	} );*/

	function get_data(){
		var search_keyword = $("#search").val();
		$.ajax({
			url :"get_data.php",
			type :"POST",
			data :{
				keyword : search_keyword
			},
			cache :false,
			success :function(response){
				console.log(response);
				$("#example").html(response);


			}

		});
	}

	function submit_data(){
		var name = $("#name").val();
		var number = $("#number").val();
		var email = $("#email").val();

		$.ajax({
			url : "upload.php",
			type : "POST",
			data :{
				name : name,
				number : number,
				email : email
			},
			cache : false,
			success : function(response){
				console.log(response);
				alert("Data Inserted");
				$("#name").val("");
				$("#number").val("");
				$("#email").val("");


			}

		});
	}
</script>

</body>
</html>





