<?php
	$con = mysqli_connect("localhost","root","","demo"); 

	$name = $_POST['name'];
	$number =  $_POST['number'];
	$email = $_POST['email'];

	mysqli_query($con,"INSERT into data values(null,'$name','$number','$email')");

	echo "INSERT into data values(null,'$name','$number','$email')";
 ?>